from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.utils import timezone
from django.http import JsonResponse
from .models import Chat, ChatMember, Message, UserStatus

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            UserStatus.objects.create(user=user)
            login(request, user)
            return redirect('/')
    return render(request, 'app/register.html', {'form': UserCreationForm()})

def login_view(request):
    if request.method == 'POST':
        user = authenticate(username=request.POST['username'], password=request.POST['password'])
        if user:
            login(request, user)
            status, _ = UserStatus.objects.get_or_create(user=user)
            status.is_online = True
            status.save()
            return redirect('/')
    return render(request, 'app/login.html', {'form': AuthenticationForm()})

def logout_view(request):
    if request.user.is_authenticated:
        UserStatus.objects.filter(user=request.user).update(is_online=False)
    logout(request)
    return redirect('/accounts/login/')

@login_required
def chat_list(request):
    status, _ = UserStatus.objects.get_or_create(user=request.user)
    status.last_seen = timezone.now()
    status.save()
    return render(request, 'app/chat_list.html', {
        'chats': Chat.objects.filter(members__user=request.user).distinct(),
    })

@login_required
def create_chat(request):
    if request.method == 'POST':
        chat = Chat.objects.create(
            name=request.POST.get('name'), 
            is_group=request.POST.get('is_group') == 'on'
        )
        ChatMember.objects.create(chat=chat, user=request.user)
        return redirect(f'/chat/{chat.id}/')
    return render(request, 'app/create_chat.html')

@login_required
def chat_detail(request, chat_id):
    chat = get_object_or_404(Chat, id=chat_id)
    if not ChatMember.objects.filter(chat=chat, user=request.user).exists(): 
        return redirect('/')
    return render(request, 'app/chat_detail.html', {
        'chat': chat,
        'messages': Message.objects.filter(chat=chat).order_by('created_at')[:50],
        'members': User.objects.filter(memberships__chat=chat)
    })

@login_required
def add_user_to_chat(request, chat_id):
    if request.method == 'POST':
        try:
            user = User.objects.get(username=request.POST['username'])
            ChatMember.objects.get_or_create(chat_id=chat_id, user=user)
        except: pass
    return redirect(f'/chat/{chat_id}/')

@login_required
def update_status(request):
    if request.method == 'POST':
        status = UserStatus.objects.get(user=request.user)
        status.last_seen = timezone.now()
        status.save()
        return JsonResponse({'status': 'ok'})
    return JsonResponse({'status': 'error'}, status=400)