import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from .models import ChatMember, Message
from django.utils import timezone

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.chat_id = self.scope['url_route']['kwargs']['chat_id']
        self.room_group_name = f'chat_{self.chat_id}'
        
        if not self.scope['user'].is_authenticated or not await self.has_access():
            await self.close()
            return
        
        await self.channel_layer.group_add(self.room_group_name, self.channel_name)
        await self.accept()
    
    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.room_group_name, self.channel_name)
    
    async def receive(self, text_data):
        data = json.loads(text_data)
        message = data.get('message', '').strip()
        if not message: return
        
        user = self.scope['user']
        await self.save_message(message)
        
        await self.channel_layer.group_send(self.room_group_name, {
            'type': 'chat_message',
            'message': message,
            'username': user.username,
            'user_id': user.id,
            'timestamp': timezone.now().strftime('%H:%M')
        })
    
    async def chat_message(self, event):
        await self.send(text_data=json.dumps({
            'message': event['message'],
            'username': event['username'],
            'user_id': event['user_id'],
            'timestamp': event['timestamp']
        }))
    
    @database_sync_to_async
    def save_message(self, content):
        return Message.objects.create(chat_id=self.chat_id, user=self.scope['user'], content=content)
    
    @database_sync_to_async
    def has_access(self):
        return ChatMember.objects.filter(chat_id=self.chat_id, user=self.scope['user']).exists()